let audioCtx = null;
let audioBuffer = null;
let currentSource = null;

let bassNode = null;
let lofiFilterNode = null;
let distortionNode = null;
let reverbDelayNode = null;
let reverbGainNode = null;
let wobbleOscNode = null;
let wobbleGainNode = null;
let analyzerNode = null;

let isPlaying = false;
let animationFrameId = null;

const fileInput = document.getElementById('audio-file');
const fileNameDisplay = document.getElementById('file-name');
const statusBadge = document.getElementById('status-badge');
const btnPlay = document.getElementById('btn-play');
const btnStop = document.getElementById('btn-stop');
const btnExport = document.getElementById('btn-export');
const exportFormat = document.getElementById('export-format');
const progressContainer = document.getElementById('progress-container');
const progressFill = document.getElementById('progress-fill');
const progressText = document.getElementById('progress-text');
const canvas = document.getElementById('visualizer-canvas');
const canvasCtx = canvas.getContext('2d');

function updateStatus(state, label) {
    statusBadge.className = `badge status-${state}`;
    statusBadge.textContent = label;
}

document.querySelectorAll('.tab-bar button').forEach(button => {
    button.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-anchor').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.view-panel').forEach(p => p.classList.remove('active'));
        
        e.currentTarget.classList.add('active');
        const targetId = e.currentTarget.getAttribute('data-target');
        document.getElementById(targetId).classList.add('active');
    });
});

function resizeCanvas() {
    canvas.width = canvas.parentElement.clientWidth * window.devicePixelRatio;
    canvas.height = canvas.parentElement.clientHeight * window.devicePixelRatio;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

fileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    
    btnPlay.disabled = true;
    btnExport.disabled = true;
    updateStatus('loading', 'Loading...');
    fileNameDisplay.textContent = "Parsing file array parameters...";

    try {
        const arrayBuffer = await file.arrayBuffer();
        audioCtx.decodeAudioData(arrayBuffer, (decodedBuffer) => {
            audioBuffer = decodedBuffer;
            fileNameDisplay.textContent = `${file.name} [${Math.round(audioBuffer.duration)}s]`;
            btnPlay.disabled = false;
            btnExport.disabled = false;
            updateStatus('idle', 'Ready');
        }, (err) => {
            alert("Codec parsing error: " + err);
            updateStatus('idle', 'Error');
        });
    } catch(err) {
        alert("Mobile system allocation block broken: " + err);
    }
});

function buildAudioPipeline() {
    if (!audioCtx || !audioBuffer) return;

    currentSource = audioCtx.createBufferSource();
    currentSource.buffer = audioBuffer;
    currentSource.loop = true;

    analyzerNode = audioCtx.createAnalyzer();
    analyzerNode.fftSize = 64;

    bassNode = audioCtx.createBiquadFilter();
    bassNode.type = 'lowshelf';
    bassNode.frequency.value = 220;

    lofiFilterNode = audioCtx.createBiquadFilter();
    lofiFilterNode.type = 'allpass';

    distortionNode = audioCtx.createWaveShaper();
    distortionNode.oversample = '4x';

    wobbleOscNode = audioCtx.createOscillator();
    wobbleGainNode = audioCtx.createGain();
    wobbleOscNode.type = 'sine';
    wobbleOscNode.frequency.value = 4.2;
    wobbleGainNode.gain.value = 0.0;

    wobbleOscNode.connect(wobbleGainNode);
    wobbleGainNode.connect(currentSource.playbackRate);

    reverbDelayNode = audioCtx.createDelay();
    reverbGainNode = audioCtx.createGain();
    reverbDelayNode.delayTime.value = 0.26;
    reverbDelayNode.connect(reverbGainNode);
    reverbGainNode.connect(reverbDelayNode);

    currentSource.connect(bassNode);
    bassNode.connect(lofiFilterNode);
    lofiFilterNode.connect(distortionNode);
    distortionNode.connect(analyzerNode);
    analyzerNode.connect(audioCtx.destination);
    
    distortionNode.connect(reverbDelayNode);
    reverbGainNode.connect(audioCtx.destination);

    wobbleOscNode.start(0);
    applyLiveSliders();
    drawVisualizer();
}

function applyLiveSliders() {
    if (!currentSource) return;

    const speed = parseFloat(document.getElementById('fx-speed').value);
    const reverbVal = parseFloat(document.getElementById('fx-reverb').value) / 100;
    const lofiVal = parseFloat(document.getElementById('fx-lofi').value) / 100;
    const wobbleVal = parseFloat(document.getElementById('fx-wobble').value) / 100;
    const bass = parseFloat(document.getElementById('fx-bass').value);
    const driveVal = parseFloat(document.getElementById('fx-drive').value) / 100;

    document.getElementById('val-speed').textContent = speed.toFixed(2) + "x";
    document.getElementById('val-reverb').textContent = Math.round(reverbVal * 100) + "%";
    document.getElementById('val-lofi').textContent = Math.round(lofiVal * 100) + "%";
    document.getElementById('val-wobble').textContent = Math.round(wobbleVal * 100) + "%";
    document.getElementById('val-bass').textContent = bass + " dB";
    document.getElementById('val-drive').textContent = Math.round(driveVal * 100) + "%";

    currentSource.playbackRate.value = speed;
    reverbGainNode.gain.value = reverbVal * 0.60;
    bassNode.gain.value = bass;
    wobbleGainNode.gain.value = wobbleVal * 0.010;

    if (lofiVal > 0.05) {
        lofiFilterNode.type = 'bandpass';
        lofiFilterNode.frequency.value = 1350 - (lofiVal * 550);
        lofiFilterNode.Q.value = 1.0 + (lofiVal * 2.5);
    } else {
        lofiFilterNode.type = 'allpass';
    }

    if (driveVal > 0.02) {
        const k = driveVal * 35;
        const n_samples = 44100;
        const curve = new Float32Array(n_samples);
        const deg = Math.PI / 180;
        for (let i = 0 ; i < n_samples; ++i ) {
            const x = (i * 2) / n_samples - 1;
            curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
        }
        distortionNode.curve = curve;
    } else {
        distortionNode.curve = null;
    }
}

function drawVisualizer() {
    if (!isPlaying || !analyzerNode) return;
    animationFrameId = requestAnimationFrame(drawVisualizer);
    
    const bufferLength = analyzerNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    analyzerNode.getByteFrequencyData(dataArray);
    
    canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
    
    const barWidth = (canvas.width / bufferLength) * 1.5;
    let barHeight; let x = 0;
    
    for (let i = 0; i < bufferLength; i++) {
        barHeight = (dataArray[i] / 255) * canvas.height * 0.80;
        canvasCtx.fillStyle = `rgba(192, 132, 252, ${barHeight / canvas.height + 0.15})`;
        canvasCtx.fillRect(x, canvas.height - barHeight, barWidth - 3, barHeight);
        x += barWidth;
    }
}

btnPlay.addEventListener('click', () => {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    stopPlayback();
    isPlaying = true;
    buildAudioPipeline();
    currentSource.start(0);
    btnStop.disabled = false;
    updateStatus('playing', 'LIVE');
});

btnStop.addEventListener('click', stopPlayback);

function stopPlayback() {
    isPlaying = false;
    if (animationFrameId) cancelAnimationFrame(animationFrameId);
    if (currentSource) {
        try { currentSource.stop(); } catch(e) {}
        currentSource.disconnect(); currentSource = null;
    }
    if (wobbleOscNode) {
        try { wobbleOscNode.stop(); } catch(e) {}
        wobbleOscNode.disconnect();
    }
    canvasCtx.clearRect(0, 0, canvas.width, canvas.height);
    btnStop.disabled = true;
    updateStatus('idle', 'Ready');
}

['fx-speed', 'fx-reverb', 'fx-lofi', 'fx-wobble', 'fx-bass', 'fx-drive'].forEach(id => {
    document.getElementById(id).addEventListener('input', applyLiveSliders);
});

document.querySelectorAll('.preset-tile').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const preset = e.currentTarget.getAttribute('data-preset');
        
        document.getElementById('fx-speed').value = 1.00;
        document.getElementById('fx-reverb').value = 0;
        document.getElementById('fx-lofi').value = 0;
        document.getElementById('fx-wobble').value = 0;
        document.getElementById('fx-bass').value = 0;
        document.getElementById('fx-drive').value = 0;

        switch(preset) {
            case 'slowed-reverb':
                document.getElementById('fx-speed').value = 0.85;
                document.getElementById('fx-reverb').value = 60;
                document.getElementById('fx-bass').value = 5.0;
                break;
            case 'lofi-slowed':
                document.getElementById('fx-speed').value = 0.88;
                document.getElementById('fx-lofi').value = 70;
                document.getElementById('fx-wobble').value = 30;
                document.getElementById('fx-drive').value = 15;
                break;
            case 'dreamy-echo':
                document.getElementById('fx-speed').value = 0.80;
                document.getElementById('fx-reverb').value = 85;
                break;
            case 'vinyl-chill':
                document.getElementById('fx-speed').value = 0.92;
                document.getElementById('fx-lofi').value = 35;
                document.getElementById('fx-wobble').value = 50;
                document.getElementById('fx-drive').value = 25;
                break;
        }
        
        if (currentSource) applyLiveSliders();
        else btnPlay.click();
    });
});

btnExport.addEventListener('click', async () => {
    if (!audioBuffer) return;
    
    stopPlayback();
    btnExport.disabled = true;
    btnPlay.disabled = true;
    progressContainer.style.display = 'block';
    progressFill.style.width = '10%';
    progressText.textContent = "Building Offline Audio Threads...";

    const speed = parseFloat(document.getElementById('fx-speed').value);
    const reverbVal = parseFloat(document.getElementById('fx-reverb').value) / 100;
    const lofiVal = parseFloat(document.getElementById('fx-lofi').value) / 100;
    const bass = parseFloat(document.getElementById('fx-bass').value);
    const driveVal = parseFloat(document.getElementById('fx-drive').value) / 100;
    const format = exportFormat.value;

    const targetDuration = audioBuffer.duration / speed;
    const sampleRate = audioBuffer.sampleRate;
    const totalRenderFrames = Math.floor(targetDuration * sampleRate);

    const offlineCtx = new OfflineAudioContext(2, totalRenderFrames, sampleRate);

    const offlineSource = offlineCtx.createBufferSource();
    offlineSource.buffer = audioBuffer;
    offlineSource.playbackRate.value = speed;

    const offlineBass = offlineCtx.createBiquadFilter();
    offlineBass.type = 'lowshelf';
    offlineBass.frequency.value = 220;
    offlineBass.gain.value = bass;

    const offlineLofi = offlineCtx.createBiquadFilter();
    if (lofiVal > 0.05) {
        offlineLofi.type = 'bandpass';
        offlineLofi.frequency.value = 1350 - (lofiVal * 550);
        offlineLofi.Q.value = 1.0 + (lofiVal * 2.5);
    } else {
        offlineLofi.type = 'allpass';
    }

    const offlineDistortion = offlineCtx.createWaveShaper();
    if (driveVal > 0.02) {
        const k = driveVal * 35;
        const n_samples = 44100;
        const curve = new Float32Array(n_samples);
        const deg = Math.PI / 180;
        for (let i = 0 ; i < n_samples; ++i ) {
            const x = (i * 2) / n_samples - 1;
            curve[i] = (3 + k) * x * 20 * deg / (Math.PI + k * Math.abs(x));
        }
        offlineDistortion.curve = curve;
    }

    const offlineDelay = offlineCtx.createDelay();
    const offlineRevGain = offlineCtx.createGain();
    offlineDelay.delayTime.value = 0.26;
    offlineRevGain.gain.value = reverbVal * 0.60;
    offlineDelay.connect(offlineRevGain);
    offlineRevGain.connect(offlineDelay);

    offlineSource.connect(offlineBass);
    offlineBass.connect(offlineLofi);
    offlineLofi.connect(offlineDistortion);
    offlineDistortion.connect(offlineCtx.destination);
    offlineDistortion.connect(offlineDelay);
    offlineRevGain.connect(offlineCtx.destination);

    offlineSource.start(0);

    try {
        const renderedBuffer = await offlineCtx.startRendering();
        if (format === 'wav') {
            progressFill.style.width = '90%';
            progressText.textContent = "Writing Lossless WAV Structure...";
            setTimeout(() => {
                const wavBlob = bufferToWav(renderedBuffer);
                triggerDownload(wavBlob, "waveforge_remix.wav");
                resetExportUI();
            }, 50);
        } else {
            encodeMp3Async(renderedBuffer);
        }
    } catch (err) {
        alert("Render Pipeline Broken: " + err);
        resetExportUI();
    }
});

function resetExportUI() {
    progressContainer.style.display = 'none';
    btnExport.disabled = false;
    btnPlay.disabled = false;
}

function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function bufferToWav(buffer) {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const bufferArr = new ArrayBuffer(length);
    const view = new DataView(bufferArr);
    const channels = [];
    let offset = 0; let pos = 0;

    function setUint16(data) { view.setUint16(pos, data, true); pos += 2; }
    function setUint32(data) { view.setUint32(pos, data, true); pos += 4; }

    setUint32(0x46464952); setUint32(length - 8); setUint32(0x45564157);
    setUint32(0x20746d66); setUint32(16); setUint16(1); setUint16(numOfChan);
    setUint32(buffer.sampleRate); setUint32(buffer.sampleRate * 2 * numOfChan);
    setUint16(numOfChan * 2); setUint16(16); setUint32(0x61746164);
    setUint32(length - pos - 4);

    for (let i = 0; i < numOfChan; i++) channels.push(buffer.getChannelData(i));
    while (pos < length) {
        for (let i = 0; i < numOfChan; i++) {
            let sample = Math.max(-1, Math.min(1, channels[i][offset]));
            sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
            view.setInt16(pos, sample, true); pos += 2;
        }
        offset++;
    }
    return new Blob([bufferArr], { type: 'audio/wav' });
}

function encodeMp3Async(buffer) {
    const sampleRate = buffer.sampleRate;
    const mp3encoder = new lamejs.Mp3Encoder(2, sampleRate, 192);
    const mp3Data = [];
    const left = buffer.getChannelData(0);
    const right = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : buffer.getChannelData(0);
    const sampleLength = left.length;
    const maxBlockSize = 1152;
    let encodedCount = 0;

    function processChunk() {
        if (encodedCount >= sampleLength) {
            const mp3buf = mp3encoder.flush();
            if (mp3buf.length > 0) mp3Data.push(mp3buf);
            progressFill.style.width = '100%';
            const mp3Blob = new Blob(mp3Data, { type: 'audio/mp3' });
            triggerDownload(mp3Blob, "waveforge_remix.mp3");
            resetExportUI();
            return;
        }

        const size = Math.min(sampleLength - encodedCount, maxBlockSize);
        const leftChunk = new Int16Array(size);
        const rightChunk = new Int16Array(size);

        for (let i = 0; i < size; i++) {
            let idx = encodedCount + i;
            let lSample = Math.max(-1, Math.min(1, left[idx]));
            leftChunk[i] = lSample < 0 ? lSample * 0x8000 : lSample * 0x7FFF;
            let rSample = Math.max(-1, Math.min(1, right[idx]));
            rightChunk[i] = rSample < 0 ? rSample * 0x8000 : rSample * 0x7FFF;
        }

        const mp3buf = mp3encoder.encodeBuffer(leftChunk, rightChunk);
        if (mp3buf.length > 0) mp3Data.push(mp3buf);
        encodedCount += size;

        const percent = 30 + Math.round((encodedCount / sampleLength) * 65);
        progressFill.style.width = `${percent}%`;
        progressText.textContent = `Encoding MP3... ${percent}%`;
        
        setTimeout(processChunk, 0);
    }
    processChunk();
}